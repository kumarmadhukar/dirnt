cat sv25-z3config.txt | while read -r FILENAME CONFIG; do
   rm a.out
   echo DIRNT START $FILENAME
   (/usr/bin/time -f "\t%E TIME \t%M MEMORY" timeout 15m python3 -u runDirNT.py "$FILENAME" "$CONFIG" )
   echo DIRNT END. Exicode = $?
done
