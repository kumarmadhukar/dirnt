for FNAME in ./oss-in/*_NT.c
do
   rm a.out
   echo DIRNT CHECK BEGIN $FNAME
   (/usr/bin/time -f "\t%E TIME \t%M MEMORY" timeout 15m python3 -u runDirNT.py "$FNAME" "dirnt-oss-z3-noins.config" )
   echo DIRNT CHECK END Z3 $FNAME . 15MIN EXITCODE=$?
done
