/*

Commit Number: 8852f5f8ff3d521897175ddeb711d6b77e03fa8a
URL: https://github.com/GNUnet-Mirror/GNUnet/commit/8852f5f8ff3d521897175ddeb711d6b77e03fa8a
Project Name: GNUnet
License: AGPL-3.0
termination: FALSE
*/
int main()
{
    unsigned int ui = 1;
    unsigned int size = __VERIFIER_nondet_uint();
    unsigned int BUFFSIZE = __VERIFIER_nondet_uint();
    {if( size < BUFFSIZE ) {
        size = BUFFSIZE;
}}
    while( ui < size ) {printf("DirNT State @ line17: <");printf("BUFFSIZE=%d,",BUFFSIZE);printf("size=%d,",size);printf("ui=%d,",ui);printf(">\n");
        ui *= 2;
}
    return 0;
}
