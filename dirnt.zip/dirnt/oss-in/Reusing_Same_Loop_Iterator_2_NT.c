/*
Commit Number: 24abdc9d313db1d320cb8c768c968098a4dda2c4
URL: https://github.com/bminor/binutils-gdb/commit/24abdc9d313db1d320cb8c768c968098a4dda2c4
Project Name: binutils-gdb
License: GPL2
termination: FALSE
*/
int main()
{
    int i,j;
    int num = __VERIFIER_nondet_int();
    {if( num > 65534 ) {
        return 0;
}}
    for( i = 0 ; i < num ; i++ )
    {printf("DirNT State @ line16: <");printf("i=%d,",i);printf("j=%d,",j);printf("num=%d,",num);printf(">\n");
        for( i = 0 ; i < 3 ; i++ )
        {printf("DirNT State @ line18: <");printf("i=%d,",i);printf("j=%d,",j);printf("num=%d,",num);printf(">\n");
            //do other
        }
    }
    return 0;
}
