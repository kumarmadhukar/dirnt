/*

Commit Number: 34c30c8ad3725e0c4a7242278ff2606f422cff93
URL: https://github.com/asterisk/asterisk/commit/34c30c8ad3725e0c4a7242278ff2606f422cff93
Project Name: asterisk
License: GPL-2.0
termination: FALSE
*/
int main()
{
	unsigned char c1 = __VERIFIER_nondet_uchar();
	char c2 =  __VERIFIER_nondet_char();
	unsigned char ac;
	for( ac = c1 ; ac != c2 ; ac++ )
	{printf("DirNT State @ line15: <");printf("ac=%c,",ac);printf("c1=%c,",c1);printf("c2=%c,",c2);printf(">\n");
        //do nothing;
	}
	return 0;
 }
