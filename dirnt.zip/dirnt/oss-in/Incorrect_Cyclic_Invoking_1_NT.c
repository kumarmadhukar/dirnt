/*
Commit Number: f569599ae70f0899035f8d5876a7939f629c5976
URL: https://github.com/torvalds/linux/commit/f569599ae70f0899035f8d5876a7939f629c5976
Project Name: linux
License: GPL-2.0
termination: FALSE
*/
struct cifsTconInfo{
	int ses;
}cifsTconInfo;
static int cifs_reconnect_tcon(struct cifsTconInfo *tcon, int smb_command);
//1->4
static int smb_init( int smb_command, struct cifsTconInfo *tcon)
{
	int rc = 0;
/* DIRNT */ printf("DirNT State @ line16: <");printf("tcon=%p,",(void *) tcon);printf("ses=%d,",tcon->ses);printf("smb_command=%d,",smb_command);printf(">\n");
	rc = cifs_reconnect_tcon(tcon, smb_command);
	return rc;
}
//2->1
int CIFSSMBQFSUnixInfo(const int xid, struct cifsTconInfo *tcon)
{
	int rc = 0;
/* DIRNT */ printf("DirNT State @ line24: <");printf("tcon=%p,",(void *) tcon);printf("ses=%d,",tcon->ses);printf("xid=%d,",xid);printf(">\n");
	rc = smb_init(15, tcon);
	return rc;
}
//3->2
void reset_cifs_unix_caps(int xid, struct cifsTconInfo *tcon)
{
/* DIRNT */ printf("DirNT State @ line31: <");printf("tcon=%p,",(void *) tcon);printf("ses=%d,",tcon->ses);printf("xid=%d,",xid);printf(">\n");
	if (!CIFSSMBQFSUnixInfo(xid, tcon))
	{
		//do something
	}
}
//4->3
static int cifs_reconnect_tcon(struct cifsTconInfo *tcon, int smb_command)
{
	if( !tcon )
		return 0;
	int ses = tcon->ses;
	if( ses )  {
/* DIRNT */ printf("DirNT State @ line31: <");printf("tcon=%p,",(void *) tcon);printf("smb_command=%d,",smb_command);printf("ses=%d,",tcon->ses);printf(">\n");
		reset_cifs_unix_caps(0, tcon);
        }
	return 1;
}
int main()
{
	struct cifsTconInfo t1;
	struct cifsTconInfo* tcon = &t1;
	tcon->ses =  __VERIFIER_nondet_int();
	int smb_command =  __VERIFIER_nondet_int();
	int rc = smb_init(smb_command,tcon);
	return 0;
}
