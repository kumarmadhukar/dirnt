/*
Commit Number: caa6003b6419d001593478a46fb4cbf8e502e818
URL: https://github.com/tytso/e2fsprogs/commit/caa6003b6419d001593478a46fb4cbf8e502e818
Project Name: e2fsprogs
License: GPL-2.0
termination: false
*/
int flag = 0;
int read( int loc , int len )
{
    int count = 0;
    {if( flag == 1 ) { //whether EOF or not
        return 0;
}}
    while( loc < len )
    {printf("DirNT State @ line16: <");printf("count=%d,",count);printf("flag=%d,",flag);printf("len=%d,",len);printf("loc=%d,",loc);printf(">\n");
        int num =  __VERIFIER_nondet_int();
        {if( num == 0 ) //abnormal
        {
            return -1;
        }
        else
        {
            {if( num < 0 ) {
                num =  -num;
}}
            num = num % 1000;
            count++;
            {if( num < 995 ) //read a char
            {
                loc++;
                continue;
            }
            else // EOF
            {
                flag = 1;
                return count;
            }}
        }}
    }
    return count;
}
int main()
{
    int count =__VERIFIER_nondet_int();
    {if( count <= 0 ) {
        return 0;
}}
    int ret;
    int buf = 0;
    while( count > 0 )
    {printf("DirNT State @ line52: <");printf("buf=%d,",buf);printf("count=%d,",count);printf("flag=%d,",flag);printf("ret=%d,",ret);printf(">\n");
        ret = read( buf, count );
        {if( ret < 0 ) {
            return 0;
}}
        count -= ret;
        buf += ret;
    }
    return 0;
}
