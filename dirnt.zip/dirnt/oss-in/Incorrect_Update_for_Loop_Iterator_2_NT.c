/*
Commit Number: 3322180d4b452e11545b70abc9b2d5af3d241361
URL: https://github.com/asterisk/asterisk/commit/3322180d4b452e11545b70abc9b2d5af3d241361
Project Name: asterisk
License: GPL2
termination: FALSE

*/
int main()
{
    unsigned char l = __VERIFIER_nondet_uchar();

    while( l-- )
    {printf("DirNT State @ line14: <");printf("l=%c,",l);printf(">\n");
        {if( l-- )
        {
            //loop
        }}
    }
    return 0;
}
