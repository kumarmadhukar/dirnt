// SPDX-FileCopyrightText: 2021 Y. Cyrus Liu <yliu195@stevens.edu>
//
// SPDX-License-Identifier: Apache-2.0

/*
 * Date: 2021-06-21
 * Author: yliu195@stevens.edu
 */

extern int __VERIFIER_nondet_int(void);

int main(){
    int a, x, y;
    x = __VERIFIER_nondet_int();
    y = __VERIFIER_nondet_int();
    a = 0;
    while (y > 0){printf("DirNT State @ line17: <");printf("a=%d,",a);printf("x=%d,",x);printf("y=%d,",y);printf(">\n");
        {if (x < 0 ){
            y = ~x ;
        } else {
            y = y -1;
        }}
    }
    return 0;
}
