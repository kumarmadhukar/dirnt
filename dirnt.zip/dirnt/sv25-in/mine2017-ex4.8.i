
extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
extern void __assert (const char *__assertion, const char *__file, int __line)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));

extern void abort(void);
void reach_error() { ((void) sizeof ((0) ? 1 : 0), __extension__ ({ {if (0) {;} else {__assert_fail ("0", "mine-tutorial-ex4.8.c", 3, __extension__ __PRETTY_FUNCTION__);}} })); }
void __VERIFIER_assert(int cond) { {if(!(cond)) { ERROR: {reach_error();abort();} }} }
extern _Bool __VERIFIER_nondet_bool();
int main() {
  int v = 0;
  while (__VERIFIER_nondet_bool() == 0) {printf("DirNT State @ line17: <");printf("v=%d,",v);printf(">\n");
    __VERIFIER_assert(0 <= v);
    __VERIFIER_assert(v <= 1);
    {if (v == 0)
      {v = 1;}}
  }
  return 0;
}
