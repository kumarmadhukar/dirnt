// This file is part of the SV-Benchmarks collection of verification tasks:
// https://gitlab.com/sosy-lab/benchmarking/sv-benchmarks
//
// SPDX-FileCopyrightText: 1995-1998 Eric Young <eay@cryptsoft.com>
// SPDX-FileCopyrightText: 1998-2001 The OpenSSL Project
// SPDX-FileCopyrightText: 2002-2004 The Regents of the University of California
// SPDX-FileCopyrightText: 2011-2021 The SV-Benchmarks community
//
// SPDX-License-Identifier: OpenSSL AND PostgreSQL AND Apache-2.0

extern void abort(void);
extern void __assert_fail(const char *, const char *, unsigned int, const char *) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
void reach_error() { __assert_fail("0", "s3_srvr_1b.cil.c", 3, "reach_error"); }

extern char __VERIFIER_nondet_char(void);
extern int __VERIFIER_nondet_int(void);
extern long __VERIFIER_nondet_long(void);
extern int __VERIFIER_nondet_int();
// This is a further simplified version of s3_srvr_1a.cil.c
int main() {
  int s__state ;
  int s__hit = __VERIFIER_nondet_int() ;
  int blastFlag ;
  int tmp___1;

  s__state = 8466;
  blastFlag = 0;

  while (1) {printf("DirNT State @ line29: <");printf("blastFlag=%d,",blastFlag);printf("s__hit=%d,",s__hit);printf("s__state=%d,",s__state);printf("tmp___1=%d,",tmp___1);printf(">\n");
	  {if (s__state <= 8512 && blastFlag > 2) { goto ERROR; }}
              {
                {
                  {
                    {
                      {
                        {if (s__state == 8466) {
                          goto switch_1_8466;
                        } else {
                          {
                            {
                              {if (s__state == 8512) {
                                goto switch_1_8512;
                              } else {
                                {
                                  {
                                    {
                                      {
                                        {
                                          {
                                            {
                                                {
                                                  {
                                                    {
                                                      {
                                                        {
                                                          {
                                                            {if (s__state == 8640) {
                                                              goto switch_1_8640;
                                                            } else {
                                                              {
                                                                {if (s__state == 8656) {
                                                                  goto switch_1_8656;
                                                                } else {
                                                                  {
                                                                    {
                                                                      goto end;

                                                                          switch_1_8466:
                                                                            {if (blastFlag == 0) {
                                                                              blastFlag = 2;
                                                                            }}
                                                                            {if (s__hit) {
                                                                              s__state = 8656;
                                                                            } else {
                                                                              s__state = 8512;
                                                                            }}
                                                                            goto switch_1_break;

                                                                          switch_1_8512:
                                                                            tmp___1 = __VERIFIER_nondet_int();
                                                                            {if (tmp___1) {
                                                                              s__state = 8466;
                                                                            } else {
                                                                              s__state = 8640;
                                                                            }}
                                                                            goto switch_1_break;

                                                                          switch_1_8640:
                                                                            {if (blastFlag == 3) {
                                                                              blastFlag = 4;
                                                                            }}
                                                                            {if (s__hit) {
                                                                              goto end;
                                                                            } else {
                                                                              s__state = 8656;
                                                                            }}
                                                                            goto switch_1_break;

                                                                          switch_1_8656:
                                                                            {if (blastFlag == 2) {
                                                                              blastFlag = 3;
                                                                            }}

                                                                            {if (blastFlag == 4) {
                                                                              blastFlag = 5;
                                                                            } else {
                                                                              {if (blastFlag == 5) {
                                                                                goto ERROR;
                                                                              }}
                                                                            }}
                                                                            {if (s__hit) {
                                                                              s__state = 8640;
                                                                            } else {
                                                                              goto end;
                                                                            }}
                                                                            goto switch_1_break;

                                                                    }
                                                                  }
                                                                }}
                                                              }
                                                            }}
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }}
                            }
                          }
                        }}
                      }
                    }
                  }
                }
              }
  switch_1_break: ;
  }

  end:
  return (-1);
  ERROR: {reach_error();abort();}
  return (-1);
}
