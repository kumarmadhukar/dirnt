/*
 * Date: 2013-05-02
 * Author: heizmann@informatik.uni-freiburg.de
 *
 */
typedef enum {false, true} bool;

extern int __VERIFIER_nondet_int(void);

int main()
{
    int x;
	x = 7;
	while (true) {printf("DirNT State @ line14: <");printf("x=%d,",x);printf(">\n");
		x = 2;
	}
	return 0;
}
