typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    int j;
    i = 0;
    
    while (i < 100) {printf("DirNT State @ line10: <");printf("i=%d,",i);printf("j=%d,",j);printf(">\n");
        j = 0;
        while (j < 1) {printf("DirNT State @ line12: <");printf("i=%d,",i);printf("j=%d,",j);printf(">\n");
            j = j+1;
        }
        i = i+0;
    }
    
    return 0;
}
