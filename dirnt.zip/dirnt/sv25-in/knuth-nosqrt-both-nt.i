// This file is part of the SV-Benchmarks collection of verification tasks:
// https://gitlab.com/sosy-lab/benchmarking/sv-benchmarks
//
// SPDX-FileCopyrightText: 2021 DynamiTe team <https://github.com/letonchanh/dynamite>
//
// SPDX-License-Identifier: Apache-2.0

extern unsigned __VERIFIER_nondet_uint(void);
extern double sqrt(double);
int main() {
    unsigned s, a;
    unsigned r, k, q, d, n, t;
    s = __VERIFIER_nondet_uint();
    a = __VERIFIER_nondet_uint();
    {if (s >= 8192) {
        return 0;
    }}
    {if (a <= 2) {
        return 0;
    }}
    n = s*s;
    d = a;
    r = n % d;
    t = 0;
    k = n % (d - 2);
    q = 4 * (n / (d - 2) - n / d);
    while (1) {printf("DirNT State @ line27: <");printf("a=%d,",a);printf("d=%d,",d);printf("k=%d,",k);printf("n=%d,",n);printf("q=%d,",q);printf("r=%d,",r);printf("s=%d,",s);printf("t=%d,",t);printf(">\n");
        {if (!(d * k - d * t - a * k + a * t == 0)) {break;}}
        {if (2 * r + q < k) {
            t = r;
            r = 2 * r - k + q + d + 2;
            k = t;
            q = q + 4;
            d = d + 2;
        } else {if ((2 * r + q >= k) && (2 * r + q < d + k + 2)) {
            t = r;
            r = 2 * r - k + q;
            k = t;
            d = d + 2;
        } else {if ((2 * r + q >= k) && (2 * r + q >= d + k + 2) && (2 * r + q < 2 * d + k + 4)) {
            t = r;
            r = 2 * r - k + q - d - 2;
            k = t;
            q = q - 4;
            d = d + 2;
        } else {
            t = r;
            r = 2 * r - k + q - 2 * d - 4;
            k = t;
            q = q - 8;
            d = d + 2;
        }}}}
    }
    return 0;
}
