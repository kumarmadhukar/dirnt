typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int a;
    int b;
    int i;
    a = 5;
    b = 3;
    i = 0;
    
    while (i < 10) {printf("DirNT State @ line13: <");printf("a=%d,",a);printf("b=%d,",b);printf("i=%d,",i);printf(">\n"); i = i + 0; }
    
    return 0;
}