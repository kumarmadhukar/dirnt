typedef enum { false, true } bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    i = __VERIFIER_nondet_int();
    
    while (true) {printf("DirNT State @ line9: <");printf("i=%d,",i);printf(">\n");}
    
    return 0;
}
