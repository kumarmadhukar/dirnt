/*
 * Date: 2014-06-26
 * Author: leike@informatik.uni-freiburg.de
 */

typedef enum {false, true} bool;

extern int __VERIFIER_nondet_int(void);

int main()
{
    int c, x;
	x = __VERIFIER_nondet_int();
	c = __VERIFIER_nondet_int();
	{if (c == 0) {
	    while (x >= 0) {printf("DirNT State @ line16: <");printf("c=%d,",c);printf("x=%d,",x);printf(">\n");
		    x = x + c;
	    }
    }}
	return 0;
}
