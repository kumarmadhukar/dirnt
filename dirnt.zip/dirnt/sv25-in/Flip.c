typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    int j;
    int t;
    i = __VERIFIER_nondet_int();
    j = __VERIFIER_nondet_int();
    t = 0;
    
    while (i != 0 && j != 0) {printf("DirNT State @ line13: <");printf("i=%d,",i);printf("j=%d,",j);printf("t=%d,",t);printf(">\n");
        t = i;
        i = j;
        j = t;
    }
    
    return 0;
}
