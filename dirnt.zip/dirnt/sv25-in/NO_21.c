typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    i = 0;
    
    while (i < 100) {printf("DirNT State @ line9: <");printf("i=%d,",i);printf(">\n");
        i = i+1;
        i = i-1;
    }
    
    return 0;
}
