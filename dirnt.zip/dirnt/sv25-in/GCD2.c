typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int x;
    int y;
    int tmp;
    int xtmp;
    x = __VERIFIER_nondet_int();
    y = __VERIFIER_nondet_int();
    
    while((y != 0 && x >= 0) && y >= 0) {printf("DirNT State @ line13: <");printf("tmp=%d,",tmp);printf("x=%d,",x);printf("xtmp=%d,",xtmp);printf("y=%d,",y);printf(">\n");
        tmp = y;
        xtmp = x;
        
        {if (x == y) {
            y = 0;
        }
        else {
            while(xtmp>y) {printf("DirNT State @ line21: <");printf("tmp=%d,",tmp);printf("x=%d,",x);printf("xtmp=%d,",xtmp);printf("y=%d,",y);printf(">\n");
                xtmp = xtmp - y;
            }
        }}
        
        y = xtmp;
        x = tmp;
    }
    
    return 0;
}
