typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    int j;
    j = 100;
    i = 0;
    
    while (i < j) {printf("DirNT State @ line11: <");printf("i=%d,",i);printf("j=%d,",j);printf(">\n");
        {if (51 < j) { i = i+1; j = j-1; }
        else { i = i-1; j = j+1; }}
    }
    
    return 0;
}