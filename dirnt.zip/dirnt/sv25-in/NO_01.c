typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int c;
    int i;
    c = (24*6)*6;
    
    {if (c <= 10) {
        i = 0;
        while (i < 100) {printf("DirNT State @ line12: <");printf("c=%d,",c);printf("i=%d,",i);printf(">\n");
            i = i+1;
        }
    }
    else {
        {if (c <= 50) {
            i = 0;
            while (i < 101) {printf("DirNT State @ line19: <");printf("c=%d,",c);printf("i=%d,",i);printf(">\n");
                i = i+1;
            }
        }}
        {if (c <= 100) {
            i = 0;
            while (i < 102) {printf("DirNT State @ line25: <");printf("c=%d,",c);printf("i=%d,",i);printf(">\n");
                i = i+1;
            }
        }
        else {
            i = 0;
            while (i < 103) {printf("DirNT State @ line31: <");printf("c=%d,",c);printf("i=%d,",i);printf(">\n");
                i = i+0;
            }
        }}
    }}
    
    return 0;
}
