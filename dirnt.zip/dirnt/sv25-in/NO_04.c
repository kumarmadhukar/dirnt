typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    int j;
    int k;
    int l;
    int m;
    int a;
    int b;
    i = 0;
    
    while (i < 100) {printf("DirNT State @ line15: <");printf("a=%d,",a);printf("b=%d,",b);printf("i=%d,",i);printf("j=%d,",j);printf("k=%d,",k);printf("l=%d,",l);printf("m=%d,",m);printf(">\n");
        a = i+2;
        j = 0;
        while (j < a) {printf("DirNT State @ line18: <");printf("a=%d,",a);printf("b=%d,",b);printf("i=%d,",i);printf("j=%d,",j);printf("k=%d,",k);printf("l=%d,",l);printf("m=%d,",m);printf(">\n");
            k = i+j+3;
            while (k >= 0) {printf("DirNT State @ line20: <");printf("a=%d,",a);printf("b=%d,",b);printf("i=%d,",i);printf("j=%d,",j);printf("k=%d,",k);printf("l=%d,",l);printf("m=%d,",m);printf(">\n");
                b = i+j+k+4;
                l = 0;
                while (l < b) {printf("DirNT State @ line23: <");printf("a=%d,",a);printf("b=%d,",b);printf("i=%d,",i);printf("j=%d,",j);printf("k=%d,",k);printf("l=%d,",l);printf("m=%d,",m);printf(">\n");
                    m = i+j+k+l+1000;
                    while (m >= 0) {printf("DirNT State @ line25: <");printf("a=%d,",a);printf("b=%d,",b);printf("i=%d,",i);printf("j=%d,",j);printf("k=%d,",k);printf("l=%d,",l);printf("m=%d,",m);printf(">\n");
                        m = m-0;
                    }
                    l = l+1;
                }
                k = k-1;
            }
            j = j+1;
        }
        i = i+1;
    }
    
    return 0;
}
