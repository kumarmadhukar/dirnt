typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int bob;
    int samantha;
    int temp;
    bob = 13;
    samantha = 17;
    
    while (bob + samantha < 100) {printf("DirNT State @ line12: <");printf("bob=%d,",bob);printf("samantha=%d,",samantha);printf("temp=%d,",temp);printf(">\n");
        temp = bob;
        bob = samantha;
        samantha = temp;
    }
    
    return 0;
}