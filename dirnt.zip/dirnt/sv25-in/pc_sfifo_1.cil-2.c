// This file is part of the SV-Benchmarks collection of verification tasks:
// https://gitlab.com/sosy-lab/benchmarking/sv-benchmarks
//
// SPDX-FileCopyrightText: 2011-2021 The SV-Benchmarks Community
// SPDX-FileCopyrightText: 2010 FBK-ES <https://es.fbk.eu/>
//
// SPDX-License-Identifier: Apache-2.0

extern void abort(void);
extern void __assert_fail(const char *, const char *, unsigned int, const char *) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
void reach_error() { __assert_fail("0", "pc_sfifo_1.cil-2.c", 3, "reach_error"); }

extern int __VERIFIER_nondet_int();

void error(void) 
{ 

  {
  ERROR: {reach_error();abort();}
  return;
}
}

int q_buf_0  ;
int q_free  ;
int q_read_ev  ;
int q_write_ev  ;
int p_num_write  ;
int p_last_write  ;
int p_dw_st  ;
int p_dw_pc  ;
int p_dw_i  ;
int c_num_read  ;
int c_last_read  ;
int c_dr_st  ;
int c_dr_pc  ;
int c_dr_i  ;
int is_do_write_p_triggered(void) 
{ int __retres1 ;

  {
  {if ((int )p_dw_pc == 1) {
    {if ((int )q_read_ev == 1) {
      __retres1 = 1;
      goto return_label;
    } else {

    }}
  } else {

  }}
  __retres1 = 0;
  return_label: /* CIL Label */ 
  return (__retres1);
}
}
int is_do_read_c_triggered(void) 
{ int __retres1 ;

  {
  {if ((int )c_dr_pc == 1) {
    {if ((int )q_write_ev == 1) {
      __retres1 = 1;
      goto return_label;
    } else {

    }}
  } else {

  }}
  __retres1 = 0;
  return_label: /* CIL Label */ 
  return (__retres1);
}
}
void immediate_notify_threads(void) 
{ int tmp ;
  int tmp___0 ;

  {
  {
  tmp = is_do_write_p_triggered();
  }
  {if (tmp) {
    p_dw_st = 0;
  } else {

  }}
  {
  tmp___0 = is_do_read_c_triggered();
  }
  {if (tmp___0) {
    c_dr_st = 0;
  } else {

  }}

  return;
}
}
void do_write_p(void) 
{ 


  {
  {if ((int )p_dw_pc == 0) {
    goto DW_ENTRY;
  } else {
    {if ((int )p_dw_pc == 1) {
      goto DW_WAIT_READ;
    } else {

    }}
  }}
  DW_ENTRY: 
  {
  while (1) {printf("DirNT State @ line117: <");printf("c_dr_i=%d,",c_dr_i);printf("c_dr_pc=%d,",c_dr_pc);printf("c_dr_st=%d,",c_dr_st);printf("c_last_read=%d,",c_last_read);printf("c_num_read=%d,",c_num_read);printf("p_dw_i=%d,",p_dw_i);printf("p_dw_pc=%d,",p_dw_pc);printf("p_dw_st=%d,",p_dw_st);printf("p_last_write=%d,",p_last_write);printf("p_num_write=%d,",p_num_write);printf("q_buf_0=%d,",q_buf_0);printf("q_free=%d,",q_free);printf("q_read_ev=%d,",q_read_ev);printf("q_write_ev=%d,",q_write_ev);printf(">\n");
    while_0_continue: /* CIL Label */ ;
    {if ((int )q_free == 0) {
      p_dw_st = 2;
      p_dw_pc = 1;

      goto return_label;
      DW_WAIT_READ: ;
    } else {

    }}
    {
    q_buf_0 = __VERIFIER_nondet_int();
    p_last_write = q_buf_0;
    p_num_write += 1;
    q_free = 0;
    q_write_ev = 1;
    immediate_notify_threads();
    q_write_ev = 2;
    }
  }
  while_0_break: /* CIL Label */ ;
  }
  return_label: /* CIL Label */ 
  return;
}
}
static int a_t  ;
void do_read_c(void) 
{ int a ;

  {
  {if ((int )c_dr_pc == 0) {
    goto DR_ENTRY;
  } else {
    {if ((int )c_dr_pc == 1) {
      goto DR_WAIT_WRITE;
    } else {

    }}
  }}
  DR_ENTRY: 
  {
  while (1) {printf("DirNT State @ line160: <");printf("a=%d,",a);printf("a_t=%d,",a_t);printf("c_dr_i=%d,",c_dr_i);printf("c_dr_pc=%d,",c_dr_pc);printf("c_dr_st=%d,",c_dr_st);printf("c_last_read=%d,",c_last_read);printf("c_num_read=%d,",c_num_read);printf("p_dw_i=%d,",p_dw_i);printf("p_dw_pc=%d,",p_dw_pc);printf("p_dw_st=%d,",p_dw_st);printf("p_last_write=%d,",p_last_write);printf("p_num_write=%d,",p_num_write);printf("q_buf_0=%d,",q_buf_0);printf("q_free=%d,",q_free);printf("q_read_ev=%d,",q_read_ev);printf("q_write_ev=%d,",q_write_ev);printf(">\n");
    while_1_continue: /* CIL Label */ ;
    {if ((int )q_free == 1) {
      c_dr_st = 2;
      c_dr_pc = 1;
      a_t = a;

      goto return_label;
      DR_WAIT_WRITE: 
      a = a_t;
    } else {

    }}
    {
    a = q_buf_0;
    c_last_read = a;
    c_num_read += 1;
    q_free = 1;
    q_read_ev = 1;
    immediate_notify_threads();
    q_read_ev = 2;
    }
    {if (p_last_write == c_last_read) {
      {if (p_num_write == c_num_read) {

      } else {
        {
        error();
        }
      }}
    } else {
      {
      error();
      }
    }}
  }
  while_1_break: /* CIL Label */ ;
  }
  return_label: /* CIL Label */ 
  return;
}
}
void init_threads(void) 
{ 

  {
  {if ((int )p_dw_i == 1) {
    p_dw_st = 0;
  } else {
    p_dw_st = 2;
  }}
  {if ((int )c_dr_i == 1) {
    c_dr_st = 0;
  } else {
    c_dr_st = 2;
  }}

  return;
}
}
int exists_runnable_thread(void) 
{ int __retres1 ;

  {
  {if ((int )p_dw_st == 0) {
    __retres1 = 1;
    goto return_label;
  } else {
    {if ((int )c_dr_st == 0) {
      __retres1 = 1;
      goto return_label;
    } else {

    }}
  }}
  __retres1 = 0;
  return_label: /* CIL Label */ 
  return (__retres1);
}
}
void eval(void) 
{ int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  {
  while (1) {printf("DirNT State @ line247: <");printf("a_t=%d,",a_t);printf("c_dr_i=%d,",c_dr_i);printf("c_dr_pc=%d,",c_dr_pc);printf("c_dr_st=%d,",c_dr_st);printf("c_last_read=%d,",c_last_read);printf("c_num_read=%d,",c_num_read);printf("p_dw_i=%d,",p_dw_i);printf("p_dw_pc=%d,",p_dw_pc);printf("p_dw_st=%d,",p_dw_st);printf("p_last_write=%d,",p_last_write);printf("p_num_write=%d,",p_num_write);printf("q_buf_0=%d,",q_buf_0);printf("q_free=%d,",q_free);printf("q_read_ev=%d,",q_read_ev);printf("q_write_ev=%d,",q_write_ev);printf("tmp=%d,",tmp);printf("tmp___0=%d,",tmp___0);printf("tmp___1=%d,",tmp___1);printf(">\n");
    while_2_continue: /* CIL Label */ ;
    {
    tmp___1 = exists_runnable_thread();
    }
    {if (tmp___1) {

    } else {
      goto while_2_break;
    }}
    {if ((int )p_dw_st == 0) {
      {
	tmp = __VERIFIER_nondet_int();
      }
      {if (tmp) {
        {
        p_dw_st = 1;
        do_write_p();
        }
      } else {

      }}
    } else {

    }}
    {if ((int )c_dr_st == 0) {
      {
	tmp___0 = __VERIFIER_nondet_int();
      }
      {if (tmp___0) {
        {
        c_dr_st = 1;
        do_read_c();
        }
      } else {

      }}
    } else {

    }}
  }
  while_2_break: /* CIL Label */ ;
  }

  return;
}
}
int stop_simulation(void) 
{ int tmp ;
  int __retres2 ;

  {
  {
  tmp = exists_runnable_thread();
  }
  {if (tmp) {
    __retres2 = 0;
    goto return_label;
  } else {

  }}
  __retres2 = 1;
  return_label: /* CIL Label */ 
  return (__retres2);
}
}
void start_simulation(void) 
{ int kernel_st ;
  int tmp ;

  {
  {
  kernel_st = 0;
  init_threads();
  }
  {
  while (1) {printf("DirNT State @ line323: <");printf("a_t=%d,",a_t);printf("c_dr_i=%d,",c_dr_i);printf("c_dr_pc=%d,",c_dr_pc);printf("c_dr_st=%d,",c_dr_st);printf("c_last_read=%d,",c_last_read);printf("c_num_read=%d,",c_num_read);printf("kernel_st=%d,",kernel_st);printf("p_dw_i=%d,",p_dw_i);printf("p_dw_pc=%d,",p_dw_pc);printf("p_dw_st=%d,",p_dw_st);printf("p_last_write=%d,",p_last_write);printf("p_num_write=%d,",p_num_write);printf("q_buf_0=%d,",q_buf_0);printf("q_free=%d,",q_free);printf("q_read_ev=%d,",q_read_ev);printf("q_write_ev=%d,",q_write_ev);printf("tmp=%d,",tmp);printf(">\n");
    while_3_continue: /* CIL Label */ ;
    {
    kernel_st = 1;
    eval();
    tmp = stop_simulation();
    }
    {if (tmp) {
      goto while_3_break;
    } else {

    }}
  }
  while_3_break: /* CIL Label */ ;
  }

  return;
}
}
void init_model(void) 
{ 

  {
  q_free = 1;
  q_write_ev = 2;
  q_read_ev = q_write_ev;
  p_num_write = 0;
  p_dw_pc = 0;
  p_dw_i = 1;
  c_num_read = 0;
  c_dr_pc = 0;
  c_dr_i = 1;

  return;
}
}
int main(void) 
{ int __retres1 ;

  {
  {
  init_model();
  start_simulation();
  }
  __retres1 = 0;
  return (__retres1);
}
}
