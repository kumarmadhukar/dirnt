/* ========================= dirnt_runtime.c ========================= */
#include "dirnt_runtime.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* ---------------- configuration ---------------- */
#define DIRNT_K 1000000u
#define HASH_SIZE 2097152u /* 2^21 */
#define STATE_BUF_SZ 10000u

/* ---------------- state assembly ---------------- */
static unsigned char g_buf[STATE_BUF_SZ];
static unsigned long g_len = 0; /* reset per iteration */

void dirnt_state_begin(void) { g_len = 0;}

/* pack fixed-size value */
void dirnt_pack_val(const void *p, unsigned long sz)
{
    if (g_len + sz > STATE_BUF_SZ) abort();
    memcpy(g_buf + g_len, p, sz);
    g_len += sz;
}

/* pack string as [len][bytes] */
void dirnt_pack_str(const char *s) {    unsigned long n = strlen(s);    if (g_len + sizeof(n) + n > STATE_BUF_SZ) abort();    memcpy(g_buf + g_len, &n, sizeof(n));    g_len += sizeof(n);    memcpy(g_buf + g_len, s, n);    g_len += n;}

/* ---------------- hashing ---------------- */
static inline uint64_t hash64(const void *data, unsigned long len) {    const unsigned char *p = data;    uint64_t h = 1469598103934665603ULL;    for (unsigned long i = 0; i < len; i++) {        h ^= p[i];        h *= 1099511628211ULL;    }    return h;}

/* ---------------- hash table (open addressing) ---------------- */
typedef struct {    uint64_t h;    uint64_t first_iter;    unsigned long len;    unsigned char *buf;    unsigned char used;} entry_t;
static entry_t table[HASH_SIZE];static uint64_t iter = 0;
/* terminate on lasso */
static void dirnt_die_lasso(uint64_t lasso_len,
                            uint64_t now,
                            uint64_t first) {
    fprintf(stderr,
            "DIRNT_LASSO length=%llu (iter=%llu, first=%llu)\n",
            (unsigned long long)lasso_len,
            (unsigned long long)now,
            (unsigned long long)first);
    fflush(stderr);
    exit(0);
}


/* ---------------- main check ---------------- */
void dirnt_state_end(void) {
    if (g_len == 0) {
        iter++;
        return;
    }
    uint64_t h = hash64(g_buf, g_len);
    uint32_t idx = (uint32_t)(h & (HASH_SIZE - 1));
    /* probe */
    while (table[idx].used) {
        if (table[idx].h == h &&
            table[idx].len == g_len &&
            memcmp(table[idx].buf, g_buf, g_len) == 0) {
            uint64_t lasso_len = iter - table[idx].first_iter;
            dirnt_die_lasso(lasso_len, iter, table[idx].first_iter);
        }
        idx = (idx + 1) & (HASH_SIZE - 1);
    }
    /* insert only in prefix */
    if (iter < DIRNT_K) {
        table[idx].used = 1;
        table[idx].h = h;
        table[idx].len = g_len;
        table[idx].first_iter = iter;
        table[idx].buf = (unsigned char *)malloc(g_len);
        if (!table[idx].buf) abort();
        memcpy(table[idx].buf, g_buf, g_len);
    }
    iter++;
}

void dirnt_iter_inc(void) {iter++;}
