import re, os, shutil, subprocess, signal
import xlrd
from openpyxl import Workbook, load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows
import pandas as pd
import time
import hashlib
import argparse
import json
import subprocess
import time
import re

class Config:
    def __init__(self):
        self.architecture = None

config = Config()

fInstr = False

def compact_dirnt_source(src: str):
    out, fInstr = [], False
    out.append('#include "dirnt_runtime.h"\n')
    for line in src.splitlines(keepends=True):
        # Match any line containing DirNT print sequence
        if 'printf("DirNT' not in line:
            out.append(line)
            continue

        fInstr = True
        # Capture prefix before first printf and suffix after last one
        prefix = line.split('printf("DirNT')[0]
        suffix_match = re.search(r'printf\(">\s*\\n"\);\s*(.*)', line)
        suffix = suffix_match.group(1) if suffix_match else ""

        # Collect all printf(...) occurrences
        all_printfs = re.findall(r'printf\("([^"]*)"(?:,[^)]*)?\);', line)
        args = re.findall(r'printf\("[^"]*"(?:,([^)]*))?\);', line)

        # Merge textual parts
        combined_fmt = ''.join(all_printfs)
        # Extract line number
        m = re.search(r'line\s*([0-9]+)', combined_fmt)
        if not m:
            out.append(line)
            continue
        line_no = m.group(1)

        # Remove DirNT and variable names from the format string
        body_fmt = re.sub(r'DirNT\s*State\s*@\s*line[0-9]+:\s*<', '', combined_fmt)
        body_fmt = re.sub(r'\b[^=,<>]+=', '', body_fmt)
        body_fmt = re.sub(r'[<>]', '', body_fmt).rstrip(', ')
        # Collect argument list (x,y,z,...) from each printf
        all_args = []
        for a in args:
            if a:
                all_args.append(a.strip())
        arg_list = ','.join(all_args)
        # Emit the cleaned printf, keeping prefix/suffix intact
        # Switching over to PACK implementation below
        #if arg_list:
            #out.append(f'{prefix}printf("@{line_no}:{body_fmt}",{arg_list});{suffix}\n')
        #else:
            #out.append(f'{prefix}printf("@{line_no}:{body_fmt}");{suffix}\n')
# NEW: emit DirNT PACK logic (multiple PACKs)
        out.append(prefix + "{\n")
        out.append(f" unsigned int __dirnt_loc = {line_no}u; static unsigned int __cnt = 0; __cnt++;  if (__cnt <= 1000000) {{\n")
        out.append(" DIRNT_BEGIN();\n")
        out.append(" DIRNT_PACK_VAL(__dirnt_loc);\n")
        for a in all_args: # <-- you already have this list for printf args
            out.append(f" DIRNT_PACK_VAL({a});\n")
        out.append(" DIRNT_END();\n")
        out.append("} else { if (__cnt == 1000999) __cnt = 999999;}}" + suffix + "\n")

    if not fInstr:
        print("[ERROR] No DirNT instrumentation found — check instrumenter output.")
    else:
        print("[SUCCESS] DirNT instrumentation found — compacted.")

    return "".join(out), fInstr

def is_process_terminated(proc):
    return proc.poll() is not None


def normalize_state_with_line(line):
    # Only process lines that start with "DirNT"

    line = line.strip()
    if not line.startswith("@"):
        return None

    return line


def run_with_lasso_detection(cmd, k=100000, encoding="latin-1"):
    _LASSO_RE = re.compile(r"DIRNT_LASSO\s+length=(\d+)")
    cp = subprocess.run(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE, # capture only stderr
        text=True,
        check=False,
    )
    m = _LASSO_RE.search(cp.stderr or "")
    return int(m.group(1)) if m else None


def old_run_with_lasso_detection(command, k=100000, encoding="latin-1"):
    proc = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        encoding=encoding,
        errors="strict"
    )

    seen = {} # state → first occurrence index
    stored = 0
    line_index = 0

    try:
        for line in proc.stdout:
            state = normalize_state_with_line(line)
            if not state:
                continue

            if state in seen:
                first = seen[state]
                lasso_len = line_index - first
                proc.kill()
                print ("FOUND NON-TERM\n")
                return lasso_len # Lasso detected

            if stored < k:
                seen[state] = line_index
                stored += 1

            line_index += 1

        proc.wait()
        return None # No lasso found

    except Exception as e:
        proc.kill()
        print(f"[ERROR] {e}")
        return None


def line_hash(line):
    """Compute a hash for a given line."""
    return hashlib.md5(line.encode('utf-8')).hexdigest()

def pump(inps, bound):
    for i in range(len(inps)):
        if inps[i][0] == '':
            inps[i] = ['0']*bound
        else:
            inps[i] += [inps[i][-1]]*(bound-len(inps[i]))
            
def parseCBMCOut(outFile, bound):
    result = True
    try:
        with open(outFile) as r:
            lines = r.read().splitlines()
    except UnicodeDecodeError as e:
        inputs = " "
        print(f"Error processing file: {e}")
        return inputs, result
                    
    inputs = [[''] for i in range(len(types))]
    if (re.search('VERIFICATION FAILED', lines[-1])):
        result = False
        for line in lines:
            if(re.search('__CONCRETE__', line)):
                typ = re.sub(':.*', '', re.sub('.*__CONCRETE__', '', line))
                val = re.sub(r'\(.*', '', re.sub('.*?__CONCRETE__.*:', '', line)).strip()
                if (val ==  '\''):
                   val = "'\\''"
                if (typ == 'bool'):
                    val = 'true' if val == 'TRUE' else 'false'
                if (inputs[typ2num[typ]] == ['']):
                    inputs[typ2num[typ]] = [val]
                else:
                    inputs[typ2num[typ]].append(val)
                    
                    
    pump(inputs, bound)
    return inputs, result
        
def check_if_brace_it_called(filename):
    try:
        with open(filename, 'r') as file:
            contents = file.read()
            if "brace_it_called" in contents:
                return True
            else:
                return False
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        return False
    except Exception as e:
        print(f"Error: {e}")
        return False


    
def makeConcreteInputFile(writeFile, inps):

    inpsDefn = '#define true 1 \n#define false 0\n'
    for i in range(len(inps)):
        inpsDefn += typ2origTyp[num2typ[i]] + ' inps_' + num2typ[i] + '[BOUND] = {' + ', '.join(inps[i]) +'};\n'
        
    lines = list(concretizingLines)
    newLines = [inpsDefn] + lines
    writeFile = open(writeFile, 'w')
    writeFile.writelines(newLines)
    writeFile.close()

#######################
### EXPERIMENTATION ###
#######################

def processOneFile(origFile):

    # Get the first empty row (after the populated rows)
    cbmcExecTime = 0
    noOfTests = 0
    lassoLength = 0
    nonTermCheckTime = 0

    termBehavior = 'UNKNOWN'
        
    filePath = origFile
    base_file_name_with_ext = os.path.basename(origFile)
    fileName, ext = os.path.splitext(base_file_name_with_ext)
    if (not ext in ['.c', '.i']):
        return  -1
        
    baseDir = os.path.basename(os.path.dirname(filePath))
    OUT_DIR = os.path.join(config.outDir, baseDir)
    if(not(os.path.exists(OUT_DIR))):
        os.makedirs(OUT_DIR)
    TEMP_DIR = os.path.join(OUT_DIR, fileName)
    if (not os.path.exists(TEMP_DIR)):
        os.makedirs(TEMP_DIR)
            
    # if to be braced, run bracer to enclose control statements within braces
    brace_file_name = filePath
    base_name = os.path.basename(filePath)
    base_file_name, extension = os.path.splitext(base_name)
    print("DirNT input filePath = " + filePath + "\n")
    print("Config.brace = " + config.brace + ". Config.instrument=" + config.instrument + "\n")
    if ( config.brace ==  'yes' ):
        preInstrCmd = 'bracer -in ' + filePath + ' -c';
        os.system(preInstrCmd);
        if check_if_brace_it_called("OutFile.txt"): # bracing successful
            print("BRACER STATUS=SUCCESS\n");
            brace_file_name = os.path.join(config.workDir, base_file_name + "_braced.c");
            instr_base_name = base_file_name + "_braced";
        else:
            print("BRACER STATUS=FAIL\n"); # conitnue with the original file instead of braced file

    # if to be instrumented, run instrumenter
    if ( config.instrument ==  'yes' ):
        # If bracing successful, run instrumenter on the braced  file
        # else,                  run instrumenter on the source file
        instr_base_name = base_file_name;
        instrCmd = os.path.join(config.workDir, '.', 'instrumenter') + " -in " + brace_file_name + " -r";
        os.system(instrCmd);
        instrFilePath = os.path.join(config.workDir + '/' + instr_base_name + '_instrumented.c');
        print ('INSTRUMENTED FILE=' + instrFilePath + '. BRACEFILE=' + brace_file_name + '\n')
    else:
        instrFilePath = brace_file_name
        print ('NOT-INSTRUMENTED .FILE=' + instrFilePath + '. BRACEFILE=' + brace_file_name + '\n')

    compileFile = os.path.join(config.workDir + '/' + 'cleaned.c');
    runtimeFile = os.path.join(config.workDir + '/' + 'dirnt_runtime.c');
    with open (instrFilePath) as f:
        cleaned_src, fInstr = compact_dirnt_source(f.read())
        print (cleaned_src)
        if not fInstr:
            print("DirNT instrumentation absent\n");
            return -1

    with open ("cleaned.c", "w") as f:
        f.write(cleaned_src)

    #grepCmd = 'grep -l --quiet "DirNT State" ' + instrFilePath
    #grepExitCode = os.system(grepCmd)
    #grepExitCode = grepExitCode >> 8
    #if (grepExitCode == 1):
        #print("DirNT instrumentation absent\n");
        #return -1

    print("DirNT instrumentation present\n");

    startTime = time.time()
    for unwind in [2, 4, 10, 20, 40, 101]:
        print ("OUTER LOOP: unwind = " + str(unwind) + "\n")
        for bound in [1, 2, 4, 6, 8, 10, 30]:
            print ("INNER LOOP: bound = " + str(bound) + "\n")
            if (bound >= unwind):
                break
            noOfTests += 1
                
            ################
            ### RUN CBMC ###
            ################
            # METTA FAILED cbmcOut = 'cbmcOut.u' + str(unwind) + '.b' + str(bound)
            cbmcCmd = ' /usr/bin/time -f "\t%E TIME \t%M MEMORY GL" ' + os.path.join(config.workDir, '.', 'cbmc') + ' --unwind ' +str(unwind)+ ' --no-built-in-assertions -D BOUND=' + str(bound) + ' --trace --object-bits 16 --' + config.architecture + ' ' +  filePath  + ' ' + ntInptsFile + ' ' + config.solver + '  --no-standard-checks --no-assertions --unwinding-assertions --no-self-loops-to-assumptions  --stop-on-fail  > ' + os.path.join(TEMP_DIR, 'gl.cbmcOut')
            print ("CBMC COMMAND: " + cbmcCmd + '\n');
            cbmcStartTime = time.time()
            cbmcExitCode = os.system(cbmcCmd)
            cbmcExitCode = cbmcExitCode >> 8
            cbmcEndTime = time.time()
            testRunTime = cbmcEndTime - cbmcStartTime
            cbmcExecTime += testRunTime
            print ("CBMC EXIT CODE = <" + str(cbmcExitCode) + ">\n" )
            
            if (cbmcExitCode == 137):
                termBehavior = 'OUTOFMEM'
                print ("OUTOFMEM DONE\n")
                break
            if (cbmcExitCode == 6):
                termBehavior = 'INTERNALERROR'
                print ("INTERNALERROR DONE\n")
                break
            if (cbmcExitCode == 9):
                termBehavior = 'SIGKILL'
                print ("SIGKILL DONE\n")
                break
            if (cbmcExitCode == 124):
                termBehavior = 'TIMEOUT'
                print ("TIMEOUT DONE\n")
                break

            inputs, termination = parseCBMCOut(os.path.join(TEMP_DIR, 'gl.cbmcOut'), bound)
            concretizingFilePath = os.path.join(TEMP_DIR, fileName + '_concretize.c')

            if (not termination):
                nonTermCheckStartTime = time.time()
                print ("CHECKING NOT TERMINATION\n")
                #####################
                ### CHECK NONTERM ###
                #####################
                makeConcreteInputFile(concretizingFilePath, inputs)
                if (config.architecture == '32'):
                    GCCARCH = ' -D ARCH32 '
                else:
                    GCCARCH = ' -D ARCH64 '

                print (GCCARCH)
                if(not os.path.exists(compileFile)):
                    print (compileFile + " missing for Compilation\n")
                if(not os.path.exists(concretizingFilePath)):
                    print (concretizingFilePath + " missing for compilation\n")


                #compileCmd = 'clang -D true=1 -D false=0 -D __VERIFIER_error=abort -D BOUND=' + str(bound) + GCCARCH + ' ' + compileFile + ' ' + concretizingFilePath + '  -Wno-implicit-function-declaration  2> ' + os.path.join(TEMP_DIR, 'glgccOut')
                compileCmd = 'clang -lm -O3 -fno-builtin-printf -funroll-loops -march=native -D __VERIFIER_error=abort -D BOUND=' + str(bound) + GCCARCH + ' ' + compileFile + ' ' + concretizingFilePath + ' ' + runtimeFile + '  -Wno-implicit-function-declaration  2> ' + os.path.join(TEMP_DIR, 'glgccOut')
                print ("COMMAND: " + compileCmd + '\n');
                os.system(compileCmd) 
                
                # Execute a.out to check for lasso
                if(os.path.exists(os.path.join(config.workDir, 'a.out'))):
                    print ("RUNNING a.out\n")
                    lassoLength = run_with_lasso_detection(os.path.join(config.workDir, 'a.out'));
                    print ("RUNNING a.out COMPLETED\n")
                    os.remove(os.path.abspath(os.path.join(config.workDir, 'a.out')))
                    nonTermCheckEndTime = time.time()
                    testRunTime = nonTermCheckEndTime - nonTermCheckStartTime
                    nonTermCheckTime += testRunTime 

                    if lassoLength is not None:
                        print ("FOUND NON-TERM at LASSO LEN " + str(lassoLength) + "\n")
                        termBehavior = 'NON-TERM'
                        # there are recurring states, so break      
                        break
                else:
                    termBehavior = 'Compilation-Error'
                    break
        if (termBehavior == 'Compilation-Error' or termBehavior == 'TIMEOUT' or termBehavior == 'OUTOFMEM' or termBehavior == 'SIGKILL' or termBehavior == 'NON-TERM' or termBehavior == 'INTERNALERROR'):
            print ("BEHAVIOR <" + termBehavior + ">\n")
            shutil.move(os.path.abspath(os.path.join(config.workDir, 'cleaned.c')), os.path.abspath(os.path.join(TEMP_DIR, 'cleaned.c')))
            break
    endTime = time.time()
    totalTime = endTime - startTime 
    rowNo = sheet.max_row + 1
    sheet.cell(row=rowNo, column=1, value=origFile)
    sheet.cell(row=rowNo, column=2, value=termBehavior)
    sheet.cell(row=rowNo, column=3, value=bound)
    sheet.cell(row=rowNo, column=4, value=unwind)
    sheet.cell(row=rowNo, column=5, value=cbmcExecTime)
    sheet.cell(row=rowNo, column=6, value=nonTermCheckTime)
    sheet.cell(row=rowNo, column=7, value=totalTime)
    sheet.cell(row=rowNo, column=8, value=noOfTests)
    sheet.cell(row=rowNo, column=9, value=lassoLength)
        
    shutil.copy2(os.path.abspath(instrFilePath), os.path.join(os.path.join(TEMP_DIR + '/')))
    if ( config.instrument ==  'yes' ):
        os.remove(os.path.abspath(instrFilePath))
        shutil.copy2(os.path.abspath(os.path.join(config.workDir, 'OutFile.txt')), os.path.abspath(os.path.join(TEMP_DIR, 'instr_OutFile.txt')))
        os.remove(os.path.abspath(os.path.join(config.workDir, 'OutFile.txt')))
        
    return 0


def main():
    global config, sheet
    global concretizingLines, origFile, ntInptsFile
    global types, typ2origTyp, typ2num, num2typ

    # Set up argument parser
    parser = argparse.ArgumentParser(description='Process a file and architecture.')
    parser.add_argument('origFile', type=str, help='The original file to process')
    parser.add_argument('config_file', type=str, help='Path to the configuration')

    # Parse above arguments. NOTE: the seqeunce is to be exactly as above
    args = parser.parse_args()

    # Read and parse the configuration file
    origFile = args.origFile
    with open(args.config_file, 'r') as f:
        config_data = json.load(f)

    # Assign configuration values
    config.architecture = config_data['architecture']
    config.outDir = config_data['outDir']
    config.ntInptsFile = config_data['ntInps']
    config.concretizingFile = config_data['concretizingFile']
    config.workDir = config_data['workDir']
    config.workBook = config_data['workBook']
    config.resultSheet = config_data['resultSheet']
    config.brace = config_data['brace']
    config.instrument = config_data['instrument']
    config.solver = config_data['solver'] # leave the solver empty or blank for SAT solver

    ntInptsFile = config.ntInptsFile
    if (config.architecture == '32'):
        types = ['char', 'uchar', 'short', 'ushort', 'int', 'uint', 'long', 'ulong', 'double', 'float', 'bool', 'size_t', 'pointer', 'longlong', 'ulonglong', 'unsigned_int'];
        typ2origTyp = {'char':'char', 'uchar':'unsigned char', 'short':'short', 'ushort':'unsigned short', 'int':'int', 'uint':'unsigned int', 'long':'long', 'ulong':'unsigned long', 'double':'double', 'float':'float', 'bool':'_Bool', 'size_t':'unsigned long int', 'pointer':'void *', 'longlong':'long long', 'ulonglong':'unsigned long long', 'unsigned_int':'unsigned int'}
    else:
        types = ['char', 'uchar', 'short', 'ushort', 'int', 'uint', 'long', 'ulong', 'double', 'float', 'bool', 'size_t', 'pointer', 'longlong', 'ulonglong', 'int128', 'uint128', 'unsigned_int'];
        typ2origTyp = {'char':'char', 'uchar':'unsigned char', 'short':'short', 'ushort':'unsigned short', 'int':'int', 'uint':'unsigned int', 'long':'long', 'ulong':'unsigned long', 'double':'double', 'float':'float', 'bool':'_Bool', 'size_t':'unsigned long int', 'pointer':'void *', 'longlong':'long long', 'ulonglong':'unsigned long long', 'int128':'__int128', 'uint128':'unsigned __int128', 'unsigned_int':'unsigned int'}

    typ2num = {types[i]:i for i in range(len(types))}

    num2typ = {i:types[i] for i in range(len(types))}
    # Create the outDir if not present
    if (not os.path.exists(config.outDir)):
        os.makedirs(config.outDir)

    # Load the xls workBook, if exists
    if os.path.exists(config.workBook):
        wb = load_workbook(config.workBook)
        if config.resultSheet in wb.sheetnames:
            sheet = wb[config.resultSheet]
        else:
            sheet = wb.create_sheet(config.resultSheet)
    # Else create a new workbook
    else:
        wb = Workbook()
        wb.save(config.workBook)
        sheet = wb.active
        sheet.title = config.resultSheet
        sheet.cell(row=1, column=1, value='CODE_FILE')
        sheet.cell(row=1, column=2, value='Result')
        sheet.cell(row=1, column=3, value='regEx Bound')
        sheet.cell(row=1, column=4, value='cbmc unwind')
        sheet.cell(row=1, column=5, value='cbmc execution time')
        sheet.cell(row=1, column=6, value='nonTerm check time')
        sheet.cell(row=1, column=7, value='total time')
        sheet.cell(row=1, column=8, value='No of tests generated')
        sheet.cell(row=1, column=9, value='Lasso Length')
        wb.save(config.workBook)


    # read concrete-inp file once
    read = open(config.concretizingFile, 'r')
    concretizingLines = read.readlines()
    read.close()

    # Process the file
    processOneFile(args.origFile)
    wb.save(config.workBook)

if __name__ == '__main__':

    print("""
* *                 CBMC 6.5.0 (n/a) 64-bit                * *
* *                 Copyright (C) 2001-2018                 * *
* *              Daniel Kroening, Edmund Clarke             * *
* * Carnegie Mellon University, Computer Science Department * *
* *                  kroening@kroening.com                  * *
* *        Protected in part by U.S. patent 7,225,417       * *
""", flush=True)

    main()
